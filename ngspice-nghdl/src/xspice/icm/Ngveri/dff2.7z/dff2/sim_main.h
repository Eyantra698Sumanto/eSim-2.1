void foo(void);
int a;
