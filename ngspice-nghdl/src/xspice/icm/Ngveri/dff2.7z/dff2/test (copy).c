extern "C"{
#include "foo.h"
}
int main(){
   foo();
}

