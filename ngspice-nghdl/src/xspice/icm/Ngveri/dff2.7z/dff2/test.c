
#include "sim_main.h"
int a=1;
int main(){
   foo();
}
